import os
from dotenv import load_dotenv

load_dotenv()

API_KEY = os.getenv('BINANCE_TESTNET_API_KEY')
SECRET_KEY = os.getenv('BINANCE_TESTNET_SECRET_KEY')

if not API_KEY or not SECRET_KEY:
    raise ValueError("Please set BINANCE_TESTNET_API_KEY and BINANCE_TESTNET_SECRET_KEY in .env file")

