# Binance Futures Testnet Trading Bot

## Setup
1. Register at https://testnet.binancefuture.com and generate API key/secret.
2. Copy API credentials to `.env`:
   ```
   BINANCE_TESTNET_API_KEY=your_api_key_here
   BINANCE_TESTNET_SECRET_KEY=your_secret_key_here
   ```
3. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
4. Run from project root: `python cli.py --help`

## Examples
**Market BUY:**
```
python cli.py --symbol BTCUSDT --side BUY --type MARKET --quantity 0.001
```

**Limit SELL:**
```
python cli.py --symbol BTCUSDT --side SELL --type LIMIT --quantity 0.001 --price 60000
```

## Logs
Check `logs/bot.log` for request/response details.

## Assumptions
- Symbol precision handled by Binance API.
- Testnet only - no real funds risked.

