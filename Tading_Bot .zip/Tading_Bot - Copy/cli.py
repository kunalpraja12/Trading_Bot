#!/usr/bin/env python3
import argparse
import sys
from bot.logging_config import setup_logger
from bot.orders import place_order

def main():
    # Setup logging
    logger = setup_logger('trading_bot')
    
    parser = argparse.ArgumentParser(description='Binance Futures Testnet Trading Bot')
    parser.add_argument('--symbol', required=True, help='Symbol e.g., BTCUSDT')
    parser.add_argument('--side', required=True, choices=['BUY', 'SELL'], help='Order side')
    parser.add_argument('--type', required=True, choices=['MARKET', 'LIMIT'], help='Order type')
    parser.add_argument('--quantity', type=float, required=True, help='Order quantity')
    parser.add_argument('--price', type=float, help='Price (required for LIMIT)')
    
    args = parser.parse_args()
    
    try:
        if args.type.upper() == 'LIMIT' and args.price is None:
            print("❌ Error: --price is required for LIMIT orders")
            sys.exit(1)
        
        place_order(args.symbol, args.side, args.type, args.quantity, args.price)
        
    except ValueError as e:
        print(f"❌ Validation error: {e}")
        logger.error(f"Validation error: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Failed to place order: {e}")
        logger.error(f"Order placement failed: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()

