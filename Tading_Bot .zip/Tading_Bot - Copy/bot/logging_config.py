import logging
import os
from logging.handlers import RotatingFileHandler
import logging.handlers
import json
from datetime import datetime

def setup_logger(name: str) -> logging.Logger:
    # Create logs dir
    os.makedirs('logs', exist_ok=True)
    
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    
    # File handler with rotation
    handler = RotatingFileHandler(
        'logs/bot.log', maxBytes=10*1024*1024, backupCount=5
    )
    handler.setFormatter(logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    ))
    
    logger.addHandler(handler)
    
    return logger

