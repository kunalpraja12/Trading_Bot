import re
from typing import Optional

def validate_symbol(symbol: str) -> bool:
    """Validate symbol format e.g., BTCUSDT"""
    pattern = r'^[A-Z]{3,12}USDT$'
    return bool(re.match(pattern, symbol))

def validate_side(side: str) -> bool:
    return side.upper() in ('BUY', 'SELL')

def validate_type(order_type: str) -> bool:
    return order_type.upper() in ('MARKET', 'LIMIT')

def validate_quantity(qty: str) -> bool:
    try:
        q = float(qty)
        return q > 0
    except ValueError:
        return False

def validate_price(price: Optional[str]) -> bool:
    if not price:
        return True  # Required only for LIMIT
    try:
        p = float(price)
        return p > 0
    except ValueError:
        return False

