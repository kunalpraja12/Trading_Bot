import logging
from typing import Dict, Any, Optional
from .client import BinanceTestnetClient
from .validators import (
    validate_symbol, validate_side, validate_type, 
    validate_quantity, validate_price
)

logger = logging.getLogger(__name__)

def place_order(
    symbol: str,
    side: str,
    order_type: str,
    quantity: float,
    price: Optional[float] = None
) -> Dict[str, Any]:
    """
    Main order placement function with full validation and logging.
    """
    # Validation
    if not validate_symbol(symbol):
        raise ValueError(f"Invalid symbol: {symbol}. Use e.g., BTCUSDT")
    
    if not validate_side(side):
        raise ValueError(f"Invalid side: {side}. Must be BUY or SELL")
    
    if not validate_type(order_type):
        raise ValueError(f"Invalid type: {order_type}. Must be MARKET or LIMIT")
    
    if not validate_quantity(str(quantity)):
        raise ValueError(f"Invalid quantity: {quantity}. Must be >0")
    
    if order_type.upper() == 'LIMIT' and not validate_price(str(price)):
        raise ValueError(f"Invalid price for LIMIT order: {price}. Must be >0")
    
    # Print summary
    print(f"\n=== Order Summary ===")
    print(f"Symbol: {symbol}")
    print(f"Side: {side}")
    print(f"Type: {order_type}")
    print(f"Quantity: {quantity}")
    if price:
        print(f"Price: {price}")
    print("====================\n")
    
    # Place order
    client = BinanceTestnetClient()
    order_result = client.place_order(symbol, side, order_type, quantity, price)
    
    # Print response
    print("\n=== Order Response ===")
    print(f"Order ID: {order_result.get('orderId', 'N/A')}")
    print(f"Status: {order_result.get('status', 'N/A')}")
    print(f"Executed Qty: {order_result.get('executedQty', 'N/A')}")
    print(f"Avg Price: {order_result.get('avgPrice', 'N/A')}")
    print("======================")
    
    print("\n✅ Order placed successfully!")
    return order_result

