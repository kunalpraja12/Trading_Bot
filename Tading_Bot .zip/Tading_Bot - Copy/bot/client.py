from binance.client import Client
from binance.exceptions import BinanceAPIException
from config import API_KEY, SECRET_KEY
import logging

logger = logging.getLogger(__name__)

class BinanceTestnetClient:
    def __init__(self):
        self.client = Client(API_KEY, SECRET_KEY, testnet=True)
    
    def place_order(self, symbol: str, side: str, type: str, quantity: float, price: Optional[float] = None):
        """
        Place market or limit order on USDT-M futures testnet.
        """
        try:
            logger.info(f"Placing order: symbol={symbol}, side={side}, type={type}, qty={quantity}, price={price}")
            
            order = self.client.futures_create_order(
                symbol=symbol,
                side=side,
                type=type,
                quantity=quantity,
                price=price if price else None
            )
            
            logger.info(f"Order successful: {order}")
            return order
            
        except BinanceAPIException as e:
            error_msg = f"Binance API error: {e.message}"
            logger.error(error_msg)
            raise
        except Exception as e:
            logger.error(f"Unexpected error: {str(e)}")
            raise

